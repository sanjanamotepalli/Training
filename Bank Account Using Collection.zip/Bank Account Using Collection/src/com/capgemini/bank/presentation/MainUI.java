package com.capgemini.bank.presentation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.BankAccountServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		BankAccountServiceImpl service=new BankAccountServiceImpl();
		boolean continueValue=false;
		Scanner scanner=null;
		do {
			System.out.println("***Welcome to XYZ bank***");
			System.out.println("1) Create Account");
			System.out.println("2) Show Balance");
			System.out.println("3) Deposit");
			System.out.println("4) Withdraw");
			System.out.println("5) Fund Transfer");
			System.out.println("6) Print Transaction");
			boolean choiceFlag=false;
			int choice=0;
			do {
				System.out.println("Enter you choice:");
				scanner=new Scanner(System.in);
				try {
					choice=scanner.nextInt();
					switch(choice) {
					case 1:	{
						scanner.nextLine();
						boolean nameFlag=false;
						String name="";
						do {
							System.out.println("Enter your name:");
							scanner=new Scanner(System.in);
							try {
								name=scanner.nextLine();
								service.validateName(name);
								nameFlag=true;
							}catch(BankException e) {
								nameFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!nameFlag);
						boolean mailFlag=false;
						String mail="";
						do {
							System.out.println("Enter your mail:");
							scanner=new Scanner(System.in);
							try {
								mail=scanner.nextLine();
								service.validateMail(mail);
								mailFlag=true;
							} catch (Exception e) {
								mailFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!mailFlag);
						boolean mobileFlag=false;
						String mobile="";
						do {
							System.out.println("Enter your mobile number:");
							scanner=new Scanner(System.in);
							try {
								mobile=scanner.nextLine();
								service.validateMobile(mobile);
								mobileFlag=true;
							} catch (Exception e) {
								mobileFlag=false;
								e.printStackTrace();
							}
						}while(!mobileFlag);
						boolean addressFlag=false;
						String address="";
						do {
							System.out.println("Enter your address:");
							scanner=new Scanner(System.in);
							try {
								address=scanner.nextLine();
								service.validateAddress(address);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}while(!addressFlag);
						
						Customer customer=new Customer(0,name,mail,mobile,address,0);
						int accountNo=0;
						try {
							accountNo = service.createAccount(customer);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println("Account created successfully with account number:"+accountNo);
					}
					break;
					case 2: {
						boolean accountFlag=false;
						int accountNo=0;
						double balance=0;
						do {
							System.out.println("Enter your account number:");
							scanner=new Scanner(System.in);
							try {
								accountNo=scanner.nextInt();
								accountFlag=true;
								balance = service.showBalance(accountNo);
							}catch(InputMismatchException e) {
								accountFlag=false;
								System.err.println("account number should be in digits only");
							} catch (BankException e) {
								accountFlag=false;
								e.printStackTrace();
							}
						}while(!accountFlag);
						System.out.println("your balance is:"+balance);
					}break;
					case 3: {
						boolean accountFlag=false;
						int accountNo=0;
						do {
							System.out.println("Enter your account number:");
							scanner=new Scanner(System.in);
							try {
								accountNo=scanner.nextInt();
								accountFlag=true;
							}catch(InputMismatchException e) {
								accountFlag=false;
								System.err.println("account number should be in digits only");
							}
						}while(!accountFlag);
						double amount=0;
						boolean amountFlag=false;
						do {
							System.out.println("Enter the amount you want to deposit:");
							scanner=new Scanner(System.in);
							try {
								amount=scanner.nextDouble();
								amountFlag=true;
							}catch(InputMismatchException e) {
								amountFlag=false;
								System.err.println("Amount should be in digits");
							}
						}while(!amountFlag);
						List<Transaction> transaction=new ArrayList<>();
						try {
							transaction = service.deposit(accountNo,amount);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println(transaction);
					}break;
					case 4:{
						System.out.println("Enter your account number:");
						int accountNo=scanner.nextInt();
						System.out.println("Enter the amount you want to deposit:");
						double amount=scanner.nextDouble();
						List<Transaction> transaction=new ArrayList<>();
						try {
							transaction = service.withdraw(accountNo,amount);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println(transaction);
					}break;
					case 5:{
						System.out.println("Enter your account number:");
						int sourceAccount=scanner.nextInt();
						System.out.println("Enter account number you want to tranfer to:");
						int destinationAccount=scanner.nextInt();
						System.out.println("enter the amount you want to transer:");
						double amount=scanner.nextDouble();
						List<Transaction> transaction=new ArrayList<>();
						try {
							transaction = service.fundTransfer(sourceAccount,destinationAccount,amount);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println(transaction);
					}break;
					case 6: {
						System.out.println("Enter your account number:");
						int accountNo=scanner.nextInt();
						List<Transaction> transaction=new ArrayList<>();
						try {
							transaction = service.PrintTransaction(accountNo);
						} catch (BankException e) {
							
							e.printStackTrace();
						}
						System.out.println(transaction);
					}
					default: System.out.println("input should be between 1 to 6");
					break;
					}
				} catch (InputMismatchException e) {
					System.out.println(e.getMessage());
				}
			}while(!choiceFlag);
			
		}while(!continueValue);

	}

}
