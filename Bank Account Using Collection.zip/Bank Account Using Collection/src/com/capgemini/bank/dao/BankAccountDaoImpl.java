package com.capgemini.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.utility.AccountRepositories;

public class BankAccountDaoImpl implements BankAccountDao{
	static	Map<Integer, Customer> hashMap=new HashMap<>();
	@Override
	public int createAccount(Customer customer) {
		hashMap.putAll(AccountRepositories.getCustomerList());
		int accountNo=(int)(Math.random()*1000);
		customer.setAccountNo(accountNo);
		hashMap.put(accountNo, customer);
		//System.out.println(hashMap);
		return accountNo;
	}

	@Override
	public double showBalance(int accountNo) {
		//System.out.println(hashMap);
		hashMap.putAll(AccountRepositories.getCustomerList());
		double balance=0;
		boolean status=hashMap.containsKey(accountNo);
		if(status==false) {
			try {
				throw new BankException("account number is not valid");
			}catch(BankException e) {
				System.out.println(e.getMessage());
			}
		}
		else {
			Customer customer=hashMap.get(accountNo);
			balance=customer.getBalance();
		}
		return balance;
	}

	@Override
	public List<Transaction> deposit(int accountNo,double amount) {
		hashMap.putAll(AccountRepositories.getCustomerList());
		int transactionId=(int)(Math.random()*1000);
		List<Transaction> transactionList=new ArrayList<>();
		Customer customer=hashMap.get(accountNo);
		double balance=customer.getBalance()+amount;
		String date=java.time.LocalDate.now().toString();
		Transaction transaction=new Transaction(accountNo,transactionId,"deposit",date,balance);
		transactionList.add(transaction);
		customer.setBalance(balance);
		printTransaction.add(transaction);
		return transactionList;
	}

	@Override
	public List<Transaction> withdraw(int accountNo,double amount) {
		hashMap.putAll(AccountRepositories.getCustomerList());
		int transactionId=(int)(Math.random()*1000);
		List<Transaction> transactionList=new ArrayList<>();
		Customer customer=hashMap.get(accountNo);
		double balance=customer.getBalance()-amount;
		String date=java.time.LocalDate.now().toString();
		Transaction transaction=new Transaction(accountNo,transactionId,"deposit",date,balance);
		transactionList.add(transaction);
		customer.setBalance(balance);
		printTransaction.add(transaction);
		return transactionList;
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccount,int destinationAccount,double amount) {
		hashMap.putAll(AccountRepositories.getCustomerList());
		int transactionId=(int)(Math.random()*1000);
		List<Transaction> transactionList=new ArrayList<>();
		Customer customer=hashMap.get(sourceAccount);
		double balance=customer.getBalance()-amount;
		String date=java.time.LocalDate.now().toString();
		Transaction transaction=new Transaction(sourceAccount,transactionId,"deposit",date,balance);
		transactionList.add(transaction);
		customer.setBalance(balance);
		Customer customer1=hashMap.get(destinationAccount);
		double balance1=customer1.getBalance()+amount;
		customer1.setBalance(balance);
		printTransaction.add(transaction);
		return transactionList;
	}

	@Override
	public List<Transaction> PrintTransaction(int accountNo) {
		//System.out.println(printTransaction);
		List<Transaction> transactionList=new ArrayList<>();
		int size=printTransaction.size();
		for (int i = 0; i < size; i++) {
			Transaction transaction=printTransaction.get(i);
			if(transaction.getAccount_no()==accountNo)
				transactionList.add(transaction);
		}
		return transactionList;
	}

}
