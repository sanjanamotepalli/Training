package mypack;

public class HelloMessageAnonymousClass {
public static void main(String args[]) {
	HelloMessage messageObj=new HelloMessage() {
		 public void greetSomeone(String message) {
			 System.out.println(message);
		 }
	};
	messageObj.greetSomeone("Welcome");
}
}
