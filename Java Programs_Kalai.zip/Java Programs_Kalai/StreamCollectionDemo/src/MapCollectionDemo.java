/* 
 * to perform terminal operation  to add 5 marks to existing mark96
 *
 * */

import java.util.*;
import java.util.function.Function;
import java.util.stream.*;
public class MapCollectionDemo {
	public static void main(String args[]) {
		List<Integer> numberList=Arrays.asList(2,3,1,7,5);
		
			
		Function<Integer,Integer> f=new Function<Integer,Integer>(){
			public Integer apply(Integer i) {
				return i*2;
			}
		};
		Stream<Integer> numberStream=numberList.stream();
		Stream<Integer> mapStream=numberStream.map(f);
		mapStream.forEach(System.out::println);
		
		List<Integer> markList=new ArrayList<Integer>();
		markList.add(67);
		markList.add(87);
		markList.add(75);
		markList.add(63);
		markList.add(47);
		markList.add(85);
				
		System.out.println(markList);
		List updatedMarkList=markList.stream().
				map(i->i+5).collect(Collectors.toList());
		System.out.println(updatedMarkList);
	}

}
