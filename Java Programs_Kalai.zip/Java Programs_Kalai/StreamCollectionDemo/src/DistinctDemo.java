import java.util.stream.*;
import java.util.*;
public class DistinctDemo {
	public static void main(String args[]) {
		List<Integer> numList=new ArrayList<Integer>();
		numList.add(34);
		numList.add(54);
		numList.add(13);
		numList.add(34);
		numList.add(34);
		numList.add(34);
		
		Stream<Integer> s=numList.stream();
		Stream<Integer>s1=s.distinct();
		
		System.out.println(numList);
		
		s1.forEach(System.out::println);
		
	}

}
