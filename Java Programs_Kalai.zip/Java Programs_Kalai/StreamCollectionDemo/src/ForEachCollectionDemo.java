import java.util.*;
import java.util.stream.*;
import java.util.function.*;
public class ForEachCollectionDemo {
	public static void main(String args[]) {
		List<Integer> numberList=new ArrayList<Integer>();
		numberList.add(5);
		numberList.add(7);
		numberList.add(3);
		
		System.out.println(numberList);
		
		numberList.stream().forEach(System.out::println);// method reference
		
		System.out.println();
		
		Consumer<Integer> c=i->{
			System.out.println("The square of number:"+(i*i));
		};
		
		numberList.stream().forEach(c);
		
		System.out.println();
		
		numberList.stream().forEach(i->{
			System.out.println("The cube of number:"+(i*i*i));
		});
	}

}
