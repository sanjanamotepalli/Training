/* 
 * to perform terminal operation to pick even numbers from the given list.
 * */

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
public class FilterCollectionDemo {
	public static void main(String args[]) {
		List<Integer> numberList=new ArrayList<Integer>();
		numberList.add(1);
		numberList.add(2);
		numberList.add(45);
		numberList.add(90);
		numberList.add(34);
		numberList.add(55);
		System.out.println(numberList);		
		Predicate<Integer> p=new Predicate<Integer>() {
			public boolean test(Integer i) {
				boolean val=false;
				if(i%2==0)
					val=true;
				return val;	
			}
		};
		
		Stream<Integer> numberStream =numberList.stream();
		Stream<Integer> filterStream=numberStream.filter(p);
		
		filterStream.forEach(System.out::println);
		System.out.println();
		
		List<Integer> evenList=numberList.stream().filter(i->i%2==0).collect(Collectors.toList());
		System.out.print(evenList);
		
		Stream<Integer> s=numberList.stream();
		Stream<Integer> s1=s.filter(i->i%2==0);
		List<Integer> l1=s1.collect(Collectors.toList());
		
	}

}
