//Sorted and Ordered
import java.util.*;
public class TreeSetDemo {
public static void main(String args[]){
	//TreeSet ts=new TreeSet();
	TreeSet<Integer> ts=new TreeSet<Integer>();
	ts.add(1);
	ts.add(23);
	ts.add(2);
	ts.add(2);
	ts.add(1);
	//ts.add("Hello");
	System.out.println(ts);
	
}
}
