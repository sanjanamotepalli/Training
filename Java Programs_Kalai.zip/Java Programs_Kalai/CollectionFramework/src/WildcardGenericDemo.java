import java.util.*;
public class WildcardGenericDemo {
	public static void main(String args[]) {
		
		List<Integer> intList=new ArrayList<Integer>();
		intList.add(1);
		intList.add(2);
		// intList.add("Hello"); //error
		
		List<Double> doubleList=new ArrayList<Double>();
		doubleList.add(1.2);
		doubleList.add(2.1);
		// doubleList.add("Hello"); //error
		
		List<String> nameList=new ArrayList<>();
		nameList.add("Jack");
		//nameList.add(1);//error
		
		
		List<?> randomList=new ArrayList<>();
		//randomList.add(1); //error
		
		List<? super Number> numberList=new ArrayList<>(); // write only
		numberList.add(1);
		numberList.add(1.1);
		
		 List<? super Number> numberList1= new ArrayList<>();
		 // numberList1=intList; //error - write only
		List<? extends Number> numberList2=new ArrayList<>(); //read only
		// numberList2=numberList; //error
		numberList2=intList;
		numberList2=doubleList;
		
		//numberList2.add(6.6);// error 
		
		
		
		
		
		
	}

}
