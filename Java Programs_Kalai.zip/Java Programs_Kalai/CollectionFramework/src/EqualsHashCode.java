class Student{
	int id;
	String name;
	Student(int id,String name){
		this.id=id;
		this.name=name;
	}
	@Override
	public boolean equals(Object o){
			boolean result=false;
			Student sObj=(Student)o;
			if(this.id==sObj.id && 
					this.name.equals(sObj.name))
				result=true;
			else
				result=false;
			return result;
		}
	
		@Override
		public int hashCode(){
			return 1;
		}
		
	}

public class EqualsHashCode {
	public static void main(String args[]){
		Student st1=new Student(1,"J");
		Student st2=new Student(1,"J");
		Student st3=new Student(2,"K");
		//System.out.println(st1.equals(st2));
		System.out.println(st1.hashCode());
		System.out.println(st2.hashCode());
		System.out.println(st3.hashCode());
		
		
	}

}
