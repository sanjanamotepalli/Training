import java.util.*;
//Synchronized methods
public class HashtableDemo {
	public static void main(String args[]){  
		  Hashtable hm=new Hashtable();  
		  
		  hm.put(100,"Amit");  
		  hm.put(102,"Ravi");  
		  hm.put(101,"Vijay");  
		  hm.put(103,"Rahul");  
		  Enumeration e = hm.elements(); 
		  
	        System.out.println("display values:"); 
	  
	        while (e.hasMoreElements()) { 
	            System.out.println(e.nextElement()); 
	        }  
		 }  
}
