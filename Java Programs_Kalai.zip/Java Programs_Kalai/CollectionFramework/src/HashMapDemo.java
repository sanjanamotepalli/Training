//key & value pair
//unordered and unsorted
import java.util.*;

class A{
	int a=10;
	int b=20;
}
class B{
	String a="a";
	String b="b";
}
public class HashMapDemo {
	public static void main(String args[]){
		A aobj=new A();
		B bobj=new B();
		HashMap hs=new HashMap();
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		HashMap<A,B> hm1=new HashMap<A,B>();
		hm.put(1,"One");
		hm.put(2,"Two");
	
		Set<Integer> keys = hm.keySet();
		
	    Iterator<Integer> itr = keys.iterator();
		int key;
		String value;
	    while(itr.hasNext())
	    {
	       key = itr.next();
	        value =hm.get(key);
	        System.out.println(key + " - "+ value);
	    }
	
		
	}

}
