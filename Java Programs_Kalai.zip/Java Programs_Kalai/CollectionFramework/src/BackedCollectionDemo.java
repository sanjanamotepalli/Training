import java.util.*;
public class BackedCollectionDemo {
public static void main(String args[]){
	TreeSet<Integer> ts=new TreeSet<Integer>();
	ts.add(8);
	ts.add(3);
	ts.add(4);
	ts.add(52);
	ts.add(-8);
	ts.add(35);
	System.out.println(ts);
	
	TreeSet<Integer> tsSubset=new TreeSet<Integer>();
	
	tsSubset=(TreeSet)ts.subSet(4,true,52,true);
	System.out.println(tsSubset);
	
	ts.add(33);
	System.out.println(ts);
	System.out.println(tsSubset);
	
	tsSubset.add(23);
	System.out.println(ts);
	System.out.println(tsSubset);
	
	
	
	
	
}
}
