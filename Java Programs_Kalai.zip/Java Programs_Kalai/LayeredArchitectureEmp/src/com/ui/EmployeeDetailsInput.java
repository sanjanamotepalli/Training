package com.ui;
import com.bean.*;
import com.service.*;
import java.util.*;
public class EmployeeDetailsInput {
	Scanner sc=new Scanner(System.in);
	EmployeeService empsrObj=new EmployeeService();
	void setEmployeeDetails() {
		System.out.println("Enter the employee ID:");
		int empid=sc.nextInt();
		System.out.println("Enter the employee Name:");
		String name=sc.next();
		System.out.println("Enter the salary:");
		int sal=sc.nextInt();
		
		Employee empObj=new Employee(empid,name,sal);
		empsrObj.storeEmployeeData(empObj);
		
	}
	
	void displayEmployeeDetails() {
		Employee e=empsrObj.retriveEmployeeData();
		System.out.println(e);
		
	}

}
