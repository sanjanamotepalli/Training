

//+919123456789 | +91-9123456789 | 919123456789 | 09123456789 | 9123456789|918123456789
//(\\+91(-)?|91(-)?|0(-)?)?(9)[0-9]{9}
import java.util.regex.*;
public class MobileNumberValidation {
public static void main(String args[]) {
	String mobileNo="918123456789";
	
	 if(mobileNo.matches("(\\+91(-)?|91(-)?|0(-)?)?((9)|(8)|(7))[0-9]{9}"))
		System.out.println("Valid Mobile Num");
	 else
		 System.out.println("Invalid Mobile Num");
}
}

