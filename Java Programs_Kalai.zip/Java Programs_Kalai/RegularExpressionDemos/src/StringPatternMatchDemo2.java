import java.util.regex.*;
public class StringPatternMatchDemo2 {
public static void main(String args[]){
	//String input1="ho";
	String input="Shopping, hopping, mop, chopping";
	Pattern pattern=Pattern.compile("ho");
	//Matcher matcher1=pattern.matcher(input1);
	Matcher matcherObj=pattern.matcher(input);
	//System.out.println(matcher1.matches());
	while(matcherObj.find()){
		System.out.println(matcherObj.group()+":"
				+matcherObj.start()+":"
				+matcherObj.end());
	}
}
}
