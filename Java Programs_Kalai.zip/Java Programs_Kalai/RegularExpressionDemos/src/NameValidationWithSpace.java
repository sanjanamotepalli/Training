
public class NameValidationWithSpace {
	public static void main(String args[]) {
		String name="Kalai selvi";
		
		
		if(name.matches( "[A-Z]+([ ]|[a-zA-Z]+)*" ) )
			System.out.println("valid name");
		else 
			System.out.println("Invalid name");
	}

}
