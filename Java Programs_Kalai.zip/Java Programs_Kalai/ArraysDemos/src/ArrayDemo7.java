
public class ArrayDemo7 {
	void change_I(int a[]) {
		a[0]*=2;
	}
	public static void main(String args[]) {
		ArrayDemo7 adObj=new ArrayDemo7();
		int a[]= {2};
		adObj.change_I(a);
		System.out.println(a[0]);
	}

}
