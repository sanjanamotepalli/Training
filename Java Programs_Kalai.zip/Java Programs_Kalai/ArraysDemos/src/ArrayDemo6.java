class Student{
	int regNo;
	String stuName;
	Student(){
		
	}
	Student(int rNo,String name){
		regNo=rNo;
		stuName=name;
	}
	void displayStudentDetails(){
		System.out.println("RegNo:"+regNo+" Student Name:"+stuName);
	}
}
public class ArrayDemo6 {
	public static void main(String args[]){
		Student []sObj=new Student[2];
		sObj[0]=new Student(1,"Jack");
		sObj[1]=new Student(2,"Bill");
		for(Student i:sObj)
			i.displayStudentDetails();
		
		
		Student st1=new Student(3,"Jim");
		Student st2=new Student(4,"Kate");
		Student sObj1[]=new Student[2];
		sObj1[0]=st1;
		sObj1[1]=st2;
		
		
	}

}
