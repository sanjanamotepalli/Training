
public class ArrayDemo2 {
public static void main(String args[]){
	
	
	int k[]={1,2,3};
	System.out.println(k[2]);
	int a[]=new int[]{1,2,3,4,5};
	
	
	for(int i=0;i<a.length;i++)
	
		System.out.print(a[i]+" ");
		System.out.println("\n");
		
		
	int [][]b=new int[][]{{1,2},{2,3},{4,5}};
	for(int i=0;i<b.length;i++){
		for(int j=0;j<2;j++){
			System.out.println(b[i][j]);
		}
		for(int x=0;x<b.length;x++){
			for(int y=0;y<b[x].length;y++){
				System.out.print(b[x][y]+" ");
			}
			System.out.println();
	}
}
}
}
