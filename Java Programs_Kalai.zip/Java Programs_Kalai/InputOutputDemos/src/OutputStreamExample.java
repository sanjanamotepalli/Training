import java.io.*;

public class OutputStreamExample {

    private static final String OUTPUT_FILE = "D:\\testFile.txt";
    public static void main(String[] args) {

        String content = "Hello Java Code Geeks";

        char[] chars = content.toCharArray();

        try (OutputStreamWriter outWriter = new OutputStreamWriter(new FileOutputStream(OUTPUT_FILE),"utf-8")) {

            // write the whole string
            outWriter.write(content);

            // write a substring of the original string
            outWriter.write(content,5,11);

            // write a character sequence
            outWriter.write(chars);

            // write a single character
            outWriter.write(chars[0]);

            // write sub sequence of the character array
            outWriter.write(chars,4,10);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}