import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;

public class BufferedReaderDemo2 {
	public static void main(String args[]) throws IOException{
		//FileReader fb=new FileReader("");
	BufferedReader reader =
            new BufferedReader(new FileReader("d:\\fileread.txt"));
	BufferedWriter writer =new BufferedWriter(new FileWriter("d:\\filewrite.txt"));
 String text =null;
 
	 while((text=reader.readLine())!=null) {
		 
			 writer.write(text);
	 }
	 
	 writer.close();
	 reader.close();
	 
 
  
}
}
