
public class ImplRunnable implements Runnable  {
	ImplRunnable(){
		//Thread t=new Thread(this);	
	}
	ImplRunnable(String name){
		
		Thread t=new Thread(this,name);
		t.start();
	}
public void run(){
	System.out.println(Thread.currentThread().getName());
}
public static void main(String args[]){
	ImplRunnable irObj1=new ImplRunnable("Thread1");
	ImplRunnable irObj2=new ImplRunnable("Thread2");
	ImplRunnable irObj3=new ImplRunnable();
	ImplRunnable irObj4=new ImplRunnable();
	
	String tName="Hello";
	Thread tObj=new Thread(irObj3);
	tObj.setName("Hi");
	tObj.start();
	
	Thread tObj1=new Thread(irObj4,tName);
	tObj1.start();
	Thread tObj2=new Thread(irObj4);
	tObj2.start();
	
}
}
