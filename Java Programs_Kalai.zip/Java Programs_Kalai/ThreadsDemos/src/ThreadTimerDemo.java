import java.util.*;
public class ThreadTimerDemo extends Thread {
	int timer=1000;
	int i=1;
	public void run() {
		Date d=new Date();
		
		while(true) {
			System.out.println(d);
			while(timer!=1010) {		
			try {
			Thread.sleep(timer);
			System.out.println(i);
			i++;
			timer+=1;
			}catch(Exception e) {
				System.out.println(e);
			}
			}
			timer=1000;
			i=1;
			d=new Date();
		}	
		}


	
	
	public static void main(String args[]) {
		ThreadTimerDemo ttdObj=new ThreadTimerDemo();
		ttdObj.start();
	}

}
