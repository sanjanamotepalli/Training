
public class RunnableThreadDemo implements Runnable {
	Thread t;
	public RunnableThreadDemo(String name) {
		t=new Thread(this);
		t.setName(name);
		t.start();
	}
	public void run() {
		System.out.println("run");
		
		 for(int i=0;i<5;i++) 
		 { 
			 System.out.println(t.getName()+":"+i); 
			 Thread.currentThread().getName();
			 Thread t=Thread.currentThread();
			 t.getName();		 
		 }	 
	}
	
	public static void main(String args[]) {
		RunnableThreadDemo rtd1=new RunnableThreadDemo("Hello");
		RunnableThreadDemo rtd2=new RunnableThreadDemo("Hey");
		
		/*
		 * Thread t=new Thread(rtd1); t.start();
		 */
		
		System.out.println("Main method");
		//RunnableThreadDemo rtd2=new RunnableThreadDemo(t,"Hey");
	
	}

}
