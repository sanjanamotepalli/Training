
public class ThreadSleepDemo implements Runnable  {
	ThreadSleepDemo(String name){
		Thread t=new Thread(this,name);
		t.start();
	}
public void run(){
	System.out.println(Thread.currentThread().getName()+"is running");
	while(true){
	try{
		System.out.println(Thread.currentThread().getName()+"is about to go into sleep state");
	Thread.sleep(6000);// 60000 millsec=1min
	System.out.println(Thread.currentThread().getName()+"resumed after sleep");
	}catch(InterruptedException e){
		System.out.println(e);
	}
	System.out.println(Thread.currentThread().getName()+" run ending");
	}
}
public static void main(String args[]){
	ThreadSleepDemo tsdObj1=new ThreadSleepDemo("Thread1 ");
	ThreadSleepDemo tsdObj2=new ThreadSleepDemo("Thread2 ");
}
}
