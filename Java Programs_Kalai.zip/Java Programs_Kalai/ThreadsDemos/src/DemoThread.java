
public class DemoThread implements Runnable{
	
	DemoThread(){
		Thread t=new Thread(this);
		t.start();
	}
	public void run() {
		System.out.println("Hello");
		
	}
	public static void main(String args[]) {
		DemoThread dt=new DemoThread();
	}

}
