class HelloThread extends Thread{
	HelloThread(String threadName){
		
		setName(threadName);// Thread class
		start();
	}
	public void run(){
		Thread t=Thread.currentThread();
		String s=t.getName();
		System.out.println(s+" running");
		
		System.out.println(Thread.currentThread().getName()+
				" running");
	}
}
public class ExtendingThreadClass {
	public static void main(String args[]){
		HelloThread htObj1=new HelloThread("HelloThread1");
		HelloThread htObj2=new HelloThread("HelloThread2");
	}

}
