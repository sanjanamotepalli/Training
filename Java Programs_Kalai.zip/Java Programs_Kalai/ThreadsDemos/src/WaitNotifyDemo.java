/*
 * Producer thread produce a new resource in every 1 second and put it in �taskQueue�.
Consumer thread takes 1 seconds to consume the resource from �taskQueue�.
Max capacity of taskQueue is 5 i.e. maximum 5 resources can exist inside �taskQueue� at any given time.
Both threads run infinitely.
 */
import java.util.*;
public class WaitNotifyDemo {
	public static void main(String[] args)
	   {
	      List<Integer> taskQueue = new ArrayList<Integer>();
	      int MAX_CAPACITY = 5;
	      Producer pObj=new Producer(taskQueue, MAX_CAPACITY);
	      Thread tProducer = new Thread(pObj,"Producer");
	      Thread tConsumer = 
	    		  new Thread(new Consumer(taskQueue), "Consumer");
	      tProducer.start();
	      tConsumer.start();
	   }
}
