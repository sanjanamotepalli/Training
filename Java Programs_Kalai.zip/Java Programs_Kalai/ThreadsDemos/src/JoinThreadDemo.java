
public class JoinThreadDemo {
	static int counter=0;
	public static void main(String args[]) {
		
		Thread t1=new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("Thread 1 run method called");
				for(int i=0;i<100;i++)
				{
					try {
						System.out.println("Thread will go into sleep state");
						Thread.sleep(1000);
					counter++;
					}catch(Exception e) {
						System.out.println(e);
					}
				}
				
			}
		});
		
		Thread t2=new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("Thread 2 run method called");
				for(int i=0;i<500;i++)
				{
					
					counter++;
					
				}
				
			}
		});
		
		t1.start();
		System.out.println("Thread 1 start method called");
		t2.start();
		System.out.println("Thread 2 start method called");
		
		 /*try {
		  System.out.println("Thread 1 join method will be called");
		  t1.join(); 
		 
		  }
		  catch(Exception e) { System.out.println(e);
		  
		  }*/
		 System.out.println("counter:"+counter);
		 
		
		System.out.println(counter);
		
	}

}
