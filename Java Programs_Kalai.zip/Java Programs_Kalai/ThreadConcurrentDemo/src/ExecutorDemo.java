/*{
 * 
 * Executor Interface in java.util.concurrent 
 * newSingleThreadExecutor() Creates an Executor that uses a single worker thread operating off an unbounded queue.
 */
import java.util.concurrent.*;


public class ExecutorDemo {
public static void main(String args[]){
	Executor e=Executors.newSingleThreadExecutor();
	e.execute(new MusicPlayTask());
	e.execute(new CopyTask());
	
	MusicPlayTask mpt=new MusicPlayTask();
	e.execute(mpt);
}
}
