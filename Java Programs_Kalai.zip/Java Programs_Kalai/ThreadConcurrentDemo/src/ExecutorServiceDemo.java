/*SubInterface of Executor
 * additional method submit(Callable Object)
 * Callable Object allows the task to return values
 * newFixedThreadPool() Creates a thread pool that reuses a fixed number of threads operating off a shared unbounded queue.
*/
import java.util.concurrent.*;
public class ExecutorServiceDemo {
	public static void main(String args[]){
		ExecutorService ec1=
				Executors.newSingleThreadExecutor();
		ExecutorService ec2=
				Executors.newFixedThreadPool(3);
		ec2.execute(new MusicPlayTask());
		ec2.execute(new CopyTask());
		ec2.shutdown();
	}

}
