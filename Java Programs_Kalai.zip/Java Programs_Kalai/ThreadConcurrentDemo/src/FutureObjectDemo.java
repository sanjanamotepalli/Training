import java.util.concurrent.*;
import java.util.*;
public class FutureObjectDemo {
	public static void main(String args[]){
		ExecutorService ec=Executors.newFixedThreadPool(3);
		DisplayTask dtObj1=new DisplayTask("Welcome");
		DisplayTask dtObj2=new DisplayTask("Greetings");
		Callable dtObj3=new DisplayTask("Hi");
		Future fObj1=ec.submit(dtObj1);
		Future fObj2=ec.submit(dtObj2);
		Future fObj3=ec.submit(dtObj3);
		try{
			System.out.println(fObj1.get());
			System.out.println(fObj2.get());
			System.out.println(fObj3.get());
		}
		catch(Exception e){
			System.out.println(e);
		}
		 ec.shutdown();
	}

}
