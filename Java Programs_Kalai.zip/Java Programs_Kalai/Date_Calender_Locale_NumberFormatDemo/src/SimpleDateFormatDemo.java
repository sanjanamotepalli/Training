import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
public class SimpleDateFormatDemo {
	public static void main(String args[]) {
		Date d=new Date();
		System.out.println(d);
		
		
		
		DateFormat sdf1=new SimpleDateFormat("dd-mm-yyyy");
		System.out.println(sdf1.format(d));
		
		DateFormat sdf2=new SimpleDateFormat("HH:mm:ss");	
		System.out.println(sdf2.format(d));
		
	}

}
