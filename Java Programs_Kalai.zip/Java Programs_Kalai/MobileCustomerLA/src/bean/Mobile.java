package bean;
public class Mobile {
	long mobileNo;
	String state;
	SimType simCategory;
	
	public Mobile() {
	
	}
	
	public Mobile(long mobileNo, String state, SimType simCategory) {
		super();
		this.mobileNo = mobileNo;
		this.state = state;
		this.simCategory = simCategory;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public SimType getSimCategory() {
		return simCategory;
	}
	public void setSimCategory(SimType simCategory) {
		this.simCategory = simCategory;
	}

	@Override
	public String toString() {
		return "Mobile [mobileNo=" + mobileNo + ", state=" + state + ", simCategory=" + simCategory + "]";
	}
	
	

}
