package ui;
import java.util.Scanner;

import service.CustomerService;
import service.MobileService;
import bean.Mobile;
import bean.SimType;
import bean.Customer;
import exception.CustomerMobileStateException;
public class Main {
	static MobileService msObj=new MobileService();
	static CustomerService csObj=new CustomerService();
	static Scanner sc=new Scanner(System.in);
	static int customerId=1;
	static void displayMobileDetails() {
		Mobile mObj[]=msObj.retriveMobileService();
		for(Mobile m:mObj) {
			if(m!=null)
				System.out.println(m);
		}
	}
	static void addMobileDetails() {
		System.out.println("Enter the mobile No.");
		long mNo=sc.nextLong();
		System.out.println("Enter state mobile no. belongs");
		String state=sc.next();
		System.out.println("Enter the sim type [international/national]");
		String sType=sc.next();
		SimType sCategory=SimType.valueOf(sType.toUpperCase());
		
		Mobile m=new Mobile(mNo,state,sCategory);
		msObj.storeMobileService(m);
	}
	static void addCustomerDetails() {
		System.out.println("Customer Id:"+customerId);
		System.out.println("Enter customer name:");
		String cName=sc.next();
		System.out.println("Enter state:");
		String state=sc.nextLine();
		state+=sc.nextLine();
		displayMobileDetails();
		System.out.println("Enter the mobile no.");
		long mNo=sc.nextLong();
		Mobile mObj[]=msObj.retriveMobileService();
		Mobile mo=null;
		for(Mobile m:mObj) {
			if(m!=null)
				if(m.getMobileNo()==mNo) {
					
					if(m.getState().equalsIgnoreCase(state))
						mo=m;
					else
						throw new CustomerMobileStateException();
				}
					
					
				
		}
		
		Customer c=new Customer(customerId,cName,state,mo);
		
		csObj.storeCustomerService(c);
		customerId++;
		
	}
	static void displayCustomerDetails() {
		System.out.println("Enter the customer Id");
		int c=sc.nextInt();
	Customer c1=csObj.retriveCustomerService(c);
		System.out.println(c1);
}
	
	public static void main(String args[]) {
		
		char choice='y';
		do {
		System.out.println("1. Display All the Mobile Details");
		System.out.println("2. Add new mobile detail");
		System.out.println("3. Add new customer detail");
		System.out.println("4. Display the customer detail");
		System.out.println("5. Exit");
		
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		
		switch(ch) {
		case 1:
			displayMobileDetails();
			break;
		case 2:
			addMobileDetails();
			break;
		case 3:
			addCustomerDetails();
			break;
		case 4:
			displayCustomerDetails();
			break;
		case 5:
			System.exit(0);
			break;
		default:
			break;
			
		}
		System.out.println("Do you wish to continue y/n");
		choice=sc.next().charAt(0);
		}while(choice=='y');
		
	}

}
