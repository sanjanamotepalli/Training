package dao;

import bean.Customer;

public interface CustomerDAOIntf {
	Customer retriveCustomerDetails(int custId);
	void storeCustomerDetails(Customer cObj);
}
