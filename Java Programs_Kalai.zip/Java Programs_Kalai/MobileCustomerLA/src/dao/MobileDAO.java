package dao;

import bean.Mobile;
import bean.SimType;

public class MobileDAO implements MobileDAOIntf {
	static Mobile mObj[]=new Mobile[100];

	public Mobile[] retriveMobileDetails() {
		initialMobileValues();
		return mObj;
	}
	public void storeMobileDetails(Mobile mOb) {
		int i=0;
		Mobile m[]=retriveMobileDetails();
		for(Mobile mo:m) {
			if(mo!=null)
				i++;
				
		}
		mObj[i]=mOb;
		
	}
	
	void initialMobileValues() {
		Mobile m1=new Mobile(9876544234l,"Tamil Nadu", SimType.INTERNATIONAL);
		Mobile m2=new Mobile(9886564534l,"Madhya Pradesh", SimType.INTERNATIONAL);
		mObj[0]=m1;
		mObj[1]=m2;
	}
}
