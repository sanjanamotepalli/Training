import java.util.function.*;
public class PredicateDemo {
	 public static void main(String[] args) 
	    { 
	        Predicate<Integer> lesserthan = 
	        		i -> (i > 18);  
	        System.out.println(lesserthan.test(10));  
	        boolean eligibility=lesserthan.test(10);
	        
	    } 
}
