@FunctionalInterface
interface Square{
	int calcSquare(int x);
	default void display(String s){
		System.out.println(s);
	}
	static String greet(){
		return "Welcome";
	}
}
class MySquare implements Square{
	public int calcSquare(int x){
		return x*x;
	}
}
public class FunctionalInterfaceDemo {
	public static void main(String args[]){
		Square s=(v)->v*v;
		int x=s.calcSquare(23);
		System.out.println(x);
		
		String s1=Square.greet();
		System.out.println(s1);
		
		MySquare ms=new MySquare();
		ms.display("Hello");
		Square s2=new Square(){
			public int calcSquare(int x){
				return x*x;
			}	
		};
		int ans= s2.calcSquare(2);
		System.out.println(ans);
		s2.display("Hi");
		}
	}


