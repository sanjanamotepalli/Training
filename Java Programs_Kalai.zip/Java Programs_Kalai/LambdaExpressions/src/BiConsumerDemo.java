import java.util.*;
import java.util.function.*;
public class BiConsumerDemo {
	public static void main(String[] args) {
	       Map<Integer,String> map = 
	    		   new HashMap<>();
	       map.put(1, "Mike");
	       map.put(2, "Ben");
	       map.put(3, "Chessy");
	       BiConsumer<Integer,String> biConsumer = 
	    	(key,value) -> 
	       	System.out.println(
	       			"Key:"+ key+
	       			" Value:"+ value);
	       map.forEach(biConsumer);
	   }    
}
