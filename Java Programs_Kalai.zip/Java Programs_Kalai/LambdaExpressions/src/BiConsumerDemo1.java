import java.util.*;
import java.util.function.*;
public class BiConsumerDemo1 {
	 public static void main(String args[]) 
	    { 
	  
	        // Create the first list 
	        List<Integer> lista = 
	        		new ArrayList<Integer>();
	        lista.add(2); 
	        lista.add(1); 
	        lista.add(3);  
	        // Create the second list 
	        List<Integer> listb = 
	        		new ArrayList<Integer>(); 
	        listb.add(1); 
	        listb.add(2); 
	        listb.add(3); 
	        // BiConsumer to compare both lists 
	        BiConsumer<List<Integer>, List<Integer> > 
	            equalsObj = (list1, list2) -> 
	        { 
	          boolean val=list1.equals(list2);
	          System.out.println(val);
	        }; 
	        equalsObj.accept(lista, listb); 
	        
	    } 
}
