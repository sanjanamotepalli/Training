@ FunctionalInterface
interface Bounceable{
	public void bounce();
}

class Ball implements Bounceable{
	public void bounce() {
		System.out.println("Ball bouncing");
	}
}
public class AnonymusInnerClassDemo2 {
public static void main(String args[]) {
	
	Ball b=new Ball();
	b.bounce();
	
	// Annonymus Inner class
	
	Bounceable b1=new Bounceable() {
		public void bounce() {
			System.out.println("Anonymus bouncing");
		}	
	};
	b1.bounce();
	
	// Lambda Expression
	
	Bounceable b2=()->{
		System.out.println("Lambda expression bouncing");
	};
	b2.bounce();
	}
	
}

