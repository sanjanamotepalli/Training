

@FunctionalInterface
interface Sum{
	int calcSum(int x);
	
}

class SumClass implements Sum{
	public int calcSum(int x) {
		int res=x+10;
		
		return res;
	}
}

public class LambdaExpressionDemo {
	public static void main(String args[]){
		
		SumClass scObj=new SumClass();
		int r=scObj.calcSum(12);
		System.out.println(r);
		Sum s=(v)->v+10;
		int x=s.calcSum(23);
		System.out.println(x);
		
		
	}
}





