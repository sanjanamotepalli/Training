import java.util.function.*;
public class BinaryOperatorDemo {
	public static void main(String[] args) {
	      BinaryOperator<Integer> addBo = (n1, n2) -> n1 + n2;
	      System.out.println(addBo.apply(3, 4));
	   }
}
