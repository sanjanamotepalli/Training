import java.util.function.*;
public class DoubleConsumerDemo {
	public static void main(String[] args) {
		DoubleConsumer consumer1 = (x) -> 
		System.out.println(x*x);
	    consumer1.accept(2.5);

		DoubleConsumer consumer2 = (b) -> 
		System.out.println(b * 2);
		// Using andThen()
		consumer1.andThen(consumer2).accept(10);
		
	}

}
