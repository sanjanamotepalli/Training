package com.sample.mockito.mock;
import java.util.List;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
@SuppressWarnings("all")
public class MockitoVerifyMethodExample {
		@SuppressWarnings("unchecked")
		@Test
		void test() {
			List<String> mockList = mock(List.class);
			mockList.add("Java");
			mockList.size();
			
			verify(mockList).add("Java");
		
	}

}
