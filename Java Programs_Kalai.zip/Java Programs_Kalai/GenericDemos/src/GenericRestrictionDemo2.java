import java.util.*;
class Vehicle{
	public String toString() {
		return "Vehicle";
	}
}
class Maruti extends Vehicle{
	public String toString() {
		return "Maruti";
	}
}
class Alto extends Maruti{
	public String toString() {
		return "Alto";
	}
}
class Swift extends Maruti{
	public String toString() {
		return "Swift";
	}
}
class Hundai extends Vehicle{
	public String toString() {
		return "Hundai";
	}
}
class I10 extends Hundai{
	public String toString() {
		return "I1o";
	}
}
public class GenericRestrictionDemo2 {
	public static void main(String args[]) {
	List<Vehicle> vList=new ArrayList<Vehicle>();
	vList.add(new Vehicle());
	vList.add(new Maruti());
	vList.add(new Alto());
	vList.add(new Hundai());
	vList.add(new I10());
	
	List<? extends Vehicle> eVehicleList=vList; // Reading purpose
	for(Vehicle v:eVehicleList) {
		System.out.println(v);
	}
	
	
	//eVehicleList.add(new Vehicle());//error
	//eVehicleList.add(new Maruti());// error
	
	List<Maruti> marutiList=new ArrayList<Maruti>();
	marutiList.add(new Alto());
	marutiList.add(new Swift());
	
	List<? super Maruti> sVehicleList=marutiList; // Writing purpose
	
	sVehicleList.add(new Maruti());
	sVehicleList.add(new Alto());
	//sVehicleList.add(new Hundai()); //error
	//sVehicleList.add(new I10()); //error
	//sVehicleList.add(new Vehicle()); //error
	//sVehicleList.add(new Vehicle()); //error
	
	
	System.out.println(sVehicleList);
	
	

}
}
