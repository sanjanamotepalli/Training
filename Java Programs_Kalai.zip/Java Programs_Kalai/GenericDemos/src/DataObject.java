
public class DataObject {
	private Object t;

	public Object getObject() {
		return t;
	}
	public void setObject(Object t) {
		this.t = t;
	}
}



