import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

public class AssertMethodDemos {
	
	String s1=new String("Hello");
	String s2=new String("Hello");
	String s3=s1;
	String s4=s2;
	String s5="Hi";
	
@Test
void testAssertTrue(){
	SampleSub st=new SampleSub();
	Sample s=new Sample();
	assertTrue(s instanceof Sample);
}
@Test
void testAssertFalse(){
	
		Sample s=new Sample();
		assertFalse(s instanceof SampleSub);
	}	
@Test
void testAssertSame(){
		assertSame(s1,s2);
	}
@Test
void testAssertNotSame(){
	assertNotSame(s1,s3);	
		}

@Test
void testAssertEquals(){
		assertEquals(s1,s5);
	}
@Test
void testAssertNotEquals(){
	assertNotEquals(s1,s5);	
		}
@Disabled
@Test
void testAssertAll(){
//assertAll("Hello",()->assertEquals(s1,s2),()->assertEquals(s2,s3));
assertAll("Hello",()->assertEquals(s1,s5),()->assertEquals(s2,s3));
}	
		
		
	
	

}
