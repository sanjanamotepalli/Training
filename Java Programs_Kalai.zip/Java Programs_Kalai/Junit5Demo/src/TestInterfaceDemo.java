
import org.junit.jupiter.api.*;


interface TestIntf{
	@BeforeEach
	default void testIntf(){
		System.out.println("Default interface methods");
	}
	@BeforeAll
	static void testIntf1(){
		System.out.println("static interface methods");
	}
}
public class TestInterfaceDemo implements TestIntf {
	@Test
	void test()
	{
		System.out.println("Test");
	}

}
