import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.DynamicTest.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
//@TestFactory methods must not be private or static. 
//These methods must return a Stream, Collection, or Iterator of DynamicNode instances.
//public static <T> List<T> asList(T... a) - var-args is the parameter type
// dynamicTest method accepts String and Executable as paramter
// Executable is functional interface with void execute method
public class DynamicTestDemo {
	@TestFactory
    List<DynamicTest> dynamicTestsDemo() {
        return Arrays.asList(
            dynamicTest("simple dynamic test", () -> assertTrue(false)),
            dynamicTest("Exception Executable", () -> assertTrue(true)),
            dynamicTest("simple dynamic test-2", () -> assertTrue(true))
        );
    }
	
}



