class Sample{
	
}
public class SampleSub extends Sample {

}
