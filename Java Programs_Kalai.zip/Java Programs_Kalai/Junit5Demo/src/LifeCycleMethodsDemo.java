
import org.junit.jupiter.api.*;



public class LifeCycleMethodsDemo {
	@BeforeAll
    static void initAll() {
    	System.out.println("Before All");
    }

    @BeforeEach
    void init() {
    	System.out.println("Before Each");
    }

    @Test
    void succeedingTest() {
    	System.out.println("succeeding Test ");
    	
    }

    @Test
    void failingTest() {
    	System.out.println("failing test");
      
    }

    @Test
   // @Disabled("for demonstration purposes")
    void skippedTest() {
        // not executed
    	System.out.println("skippedTest");
    }

    @Test
    void abortedTest() {
    	System.out.println("aborted test");
        //fail("test should have been aborted");
    }

    @AfterEach
    void tearDown() {
    	System.out.println("AfterEachh");
    }
    @AfterAll
    static void tearDownAll() {
    	System.out.println("After All");
    }

	

}
