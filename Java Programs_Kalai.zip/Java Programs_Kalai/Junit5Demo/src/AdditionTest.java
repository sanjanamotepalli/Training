import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AdditionTest {

	@Test
	void testAdd() {
		Addition a=new Addition();
		int expected =5;
		int actual =a.add(2,3);
		assertEquals(expected,actual);
				
	}
	
	@Test
	void testAdd1() {
		Addition a=new Addition();
		int expected =5;
		int actual =a.add(2,3);
		assertEquals(expected,actual);
				
	}

}
