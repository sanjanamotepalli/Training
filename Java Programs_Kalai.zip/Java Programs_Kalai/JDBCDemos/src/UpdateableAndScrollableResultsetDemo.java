/*
 * create table user_info(id number(10), name varchar2(200));
 * 
 * */

import java.sql.*;

public class UpdateableAndScrollableResultsetDemo {
public static void main(String args[]){
	try{
		//step1 load the driver class  
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","system","password");  
		Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                ResultSet.CONCUR_UPDATABLE);
		  ResultSet results = statement.executeQuery("SELECT id,name FROM user_info");
		  int concurrency = results.getConcurrency();
		  System.out.println(concurrency);
		  System.out.println(ResultSet.CONCUR_UPDATABLE);
          if (concurrency == ResultSet.CONCUR_UPDATABLE) {
		  
		  results.absolute (2);
		  results.updateString(2,"kkk");
		  results.updateRow();
          }
          else 
          {
              System.out.println("ResultSet is not an updatable result set.");
          }
		  
	}
	catch(Exception e){
		System.out.println(e);
	}
}
}
