import java.sql.*;
public class StatementDemo_Update {
public static void main(String args[]){
	Connection con;
	Statement st;
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password");
		st=con.createStatement();
		st.execute("update user_info set name='mike'"
				+ " where id=103");
		System.out.println("row updated");
	}catch(Exception e){
		System.out.println(e);
	}
}
}
