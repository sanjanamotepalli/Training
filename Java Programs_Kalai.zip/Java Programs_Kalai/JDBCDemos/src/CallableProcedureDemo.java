/*
create or replace procedure "INSERTR"  
(id IN NUMBER,  
name IN VARCHAR2)  
is  
begin  
insert into user_info values(id,name);  
end; 
 */
import java.sql.*;
public class CallableProcedureDemo {
	public static void main(String[] args) throws Exception{  
		  
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","system","password");  
		  
		CallableStatement stmt=con.prepareCall("{call insertR(?,?)}");  
		stmt.setInt(1,1011);  
		stmt.setString(2,"Amit");  
		stmt.execute();  
		  
		System.out.println("success");  
		}  
}
