import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class StringDateConverter {
	public static void main(String args[])throws Exception {
		Scanner sc=new Scanner(System.in);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		System.out.println("Enter a Date [yyyy-MM-dd]");
		String date=sc.next();
		LocalDate localDate = LocalDate.parse(date);
		System.out.println(localDate);
		System.out.println(localDate.getMonth());
		
		System.out.println("Enter a Date [dd-MM-yyyy]");
		String date1=sc.next();
		LocalDate localDate1 = LocalDate.parse(date1,formatter);
		System.out.println(localDate1);
		System.out.println(localDate1.getMonth());
		
		String sDate1=date;
		Date date2=new SimpleDateFormat("dd-MM-yyyy").parse(sDate1);
		System.out.println(sDate1+"\t"+date2);
		System.out.println(sDate1+"\t"+date2.getMonth());
		sc.close();
		
		
	}

}
