interface Square 
{ 
    int calculate(int x); 
    /*default String display(String s){
	   return s;
    }
	   static String greet(){
		   return "Hello";
	   }*/
   }
public class FunctionalInterfaceDemo {
	public static void main(String args[]) 
    { 
        int a = 5; 
        // lambda expression to define the calculate method 
        Square s = (y)->y*y; 
        // parameter passed and return type must be 
        // same as defined in the prototype 
        int ans = s.calculate(a); 
        System.out.println(ans); 
        
        /*
        String s1=Square.greet();
        System.out.println(s1);
        */
        
      
        
    } 
}
