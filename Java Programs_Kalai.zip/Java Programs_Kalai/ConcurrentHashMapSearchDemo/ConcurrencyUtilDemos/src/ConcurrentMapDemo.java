import java.util.concurrent.*;
public class ConcurrentMapDemo {
public static void main(String args[]){
	ConcurrentHashMap cmObj=new ConcurrentHashMap();
	// ConcurrentMap cmObj=new ConcurrentHashMap();
	 cmObj.put(100, "Jack"); 
	 //cmObj.put(101, "Kim"); 
	 cmObj.put(102, "Mesi"); 
	 System.out.println(cmObj);
	 cmObj.putIfAbsent(101, "Hello"); 
	 System.out.println(cmObj);
	 //cmObj.remove(101, "Hi");
	 cmObj.remove(101, "Hello");
	 System.out.println(cmObj);
	 cmObj.replace(102, "Mesi", "Ronaldo");
	 System.out.println(cmObj);
	 
	 
}
}
