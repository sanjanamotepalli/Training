interface Calculate 
{ 
     
   int calcuteOp(int x); 
}
public class AnonymousInnerClassDemo {
	public static void main(String args[]){
		Calculate cObj=new Calculate(){
			public int calcuteOp(int x){
				return(x*x);
			}
		};
			int calVal=cObj.calcuteOp(2);
			System.out.println(calVal);
		}
		
	}


