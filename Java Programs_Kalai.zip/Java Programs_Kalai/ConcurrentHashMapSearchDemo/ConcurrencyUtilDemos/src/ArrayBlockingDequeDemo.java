import java.util.*;
import java.util.concurrent.*;
public class ArrayBlockingDequeDemo {
	public static void main(String args[]){
		ArrayBlockingQueue adObj=new ArrayBlockingQueue(3);
		
		adObj.add("Hello");
		adObj.add("Greetings");
		adObj.add("Hi");
		System.out.println(adObj);
		
		Iterator i=adObj.iterator();
		//adObj.add("Hey");
		adObj.offer("Welcome");
		while(i.hasNext()){
			System.out.println(i.next());
		}
		
	}	

}
