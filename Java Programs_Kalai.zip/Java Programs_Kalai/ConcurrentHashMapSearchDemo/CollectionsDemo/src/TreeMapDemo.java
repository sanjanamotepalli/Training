//Sorted and Ordered
import java.util.*;
public class TreeMapDemo {
public static void main(String args[]){
	TreeMap tm=new TreeMap();
	tm.put("1", "Kate");
	tm.put("4", "Jack");
	tm.put("3", "Kim");
	tm.put("5","Rayan");
	System.out.println(tm);
	Set keys = tm.keySet();
	
    Iterator itr = keys.iterator();
    String key;
    String value;
    while(itr.hasNext())
    {
        key = (String)itr.next();
        value = (String)tm.get(key);
        System.out.println(key + " - "+ value);
    }
    System.out.println("**********");
    Set s=tm.entrySet();
    Iterator it=s.iterator();
    while(it.hasNext()){
    	Map.Entry me=(Map.Entry)it.next();
    	System.out.println(me.getKey()+" "
    	+me.getValue());
    }
	
}
}
