import java.util.*;
public class BackedCollectionDemo {
public static void main(String args[]){
	TreeSet ts=new TreeSet();
	ts.add(8);
	ts.add(3);
	ts.add(4);
	ts.add(52);
	ts.add(-8);
	ts.add(35);
	System.out.println(ts);
	
	TreeSet tsSubset=new TreeSet();
	tsSubset=(TreeSet)ts.subSet(3, 52);
	ts.add(45);
	System.out.println(tsSubset);
	
}
}
