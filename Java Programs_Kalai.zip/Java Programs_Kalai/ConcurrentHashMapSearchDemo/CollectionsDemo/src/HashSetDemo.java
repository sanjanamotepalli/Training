//Unordered and UnSorted Set
//No duplicate values
import java.util.*;
public class HashSetDemo {
	public static void main(String args[]){
		HashSet hs=new HashSet();
		Integer iObj=new Integer(5);
		hs.add(iObj);
		hs.add(1);
		hs.add(1);
		hs.add(new Float(1.2));
		hs.add(new String("hello"));
		hs.add(new Double(9.7));
		
		System.out.println(hs);
		
		Iterator i=hs.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
	}

}
