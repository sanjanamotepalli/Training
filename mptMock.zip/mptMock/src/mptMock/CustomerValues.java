package mptMock;

public class CustomerValues {
	String customerName;
	int mobileNo;
	String city;
	public CustomerValues(String customerName, int mobileNo, String city) {
		super();
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.city = city;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "CustomerValues [customerName=" + customerName + ", mobileNo=" + mobileNo + ", city=" + city + "]";
	}
	

}
