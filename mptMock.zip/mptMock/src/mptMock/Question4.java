package mptMock;


import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Question4  {
	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		TreeSet<CustomerDetails>treeSet=new TreeSet<CustomerDetails>();
	for(int i=0;i<2;i++)
	{
		System.out.println("Enter Customer id");
		int customerId=scanner.nextInt();
		System.out.println("Enter Customer name ");
		String customerName=scanner.next();
		System.out.println("Enter mobile number");
		int phoneNumber=scanner.nextInt();
		
		for(CustomerDetails c:treeSet) {
			System.out.println(c);
			
		}
			
		
		
	 }
	System.out.println("Enter an integer from the user ");
	int ch=scanner.nextInt();
	System.out.println("Enter an String from user");
	String s=scanner.next();
	System.out.println("Enter another integer from user");
	int ch1=scanner.nextInt();
	CustomerDetails c1=new CustomerDetails(ch,s,ch1);
	treeSet.remove(c1);
	System.out.println(treeSet);

	
	
	}

}
