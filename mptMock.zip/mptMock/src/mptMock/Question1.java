package mptMock;
import java.util.TreeSet;
public class Question1 {
public static void main(String args[])
{
  TreeSet<CustomerDetails>customer=new TreeSet<CustomerDetails>();
  CustomerDetails c1=new CustomerDetails(3,"sanju",1234567);
  CustomerDetails c2=new CustomerDetails(1,"raghu",1234567);
  CustomerDetails c3=new CustomerDetails(2,"anusha",1234567);
  customer.add(c1);
  customer.add(c2);
  customer.add(c3);
  
	for(CustomerDetails c:customer)
	{
		System.out.println(c.customerId+" "+c.customerName+" "+c.phoneNumber);
	}
		
}

}
