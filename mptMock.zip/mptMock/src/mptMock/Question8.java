package mptMock;
import java.util.*;
public class Question8 {
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
	Vector<CustomerDetails>vec=new Vector<CustomerDetails>();
	vec.add(new CustomerDetails(1,"sanju",1234));
	vec.add(new CustomerDetails(2,"anu",1234));
	vec.add(new CustomerDetails(3,"lavanya",1234));
	vec.add(new CustomerDetails(1,"sanju",1234));
	System.out.println(vec);
	System.out.println("Enter an integer from the user ");
	int ch=scanner.nextInt();
	System.out.println("Enter an String from user");
	String s=scanner.next();
	System.out.println("Enter another integer from user");
	int ch1=scanner.nextInt();
	CustomerDetails c1=new CustomerDetails(ch,s,ch1);
	vec.remove(1);
	System.out.println(vec);
}
}
