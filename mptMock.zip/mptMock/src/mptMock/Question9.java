package mptMock;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Question9 {
	public static void main(String args[])
	{
		LinkedList<CustomerDetails>linkedList=new LinkedList<CustomerDetails>();
		linkedList.add(new CustomerDetails(1,"sanju",1234));
		linkedList.add(new CustomerDetails(2,"anu",1234));
	linkedList.add(new CustomerDetails(3,"lavanya",1234));
		linkedList.add(new CustomerDetails(8,"sanju",1234));
		
		CustomerDetails c1=new CustomerDetails(5,"raghu",7890);
		linkedList.add(4,c1);
		linkedList.remove(3);
		Iterator iterator=linkedList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		//System.out.println(linkedList.get(2));
		
		
		
		
		
	}

}
