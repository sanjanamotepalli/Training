package mptMock;

import java.util.*;

public class Question7 {
	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		Hashtable<Integer,String>hashTable=new Hashtable<Integer,String>();
		System.out.println("How many entries to enter");
		int choice=scanner.nextInt();
		for(int i=0;i<choice;i++)
		{
			System.out.println("Enter key");
			int id=scanner.nextInt();
			System.out.println("Enter value");
			String value=scanner.next();
			
			hashTable.put(id,value);
		}
		Set<Integer>set=hashTable.keySet();
		Iterator<Integer>iterator=set.iterator();
		while(iterator.hasNext())
		{
			int key=iterator.next();
			String str=hashTable.get(key);
			System.out.println(key+":"+str);
		}
		
	}

	
	}


