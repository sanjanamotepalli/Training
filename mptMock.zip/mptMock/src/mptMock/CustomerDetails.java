package mptMock;
public class CustomerDetails implements Comparable<CustomerDetails> {
	public int customerId;
	public String customerName;
	public int phoneNumber;
	public CustomerDetails(int customerId, String customerName, int phoneNumber) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
	}
	public int compareTo(CustomerDetails c)
	{
		if(customerId>c.customerId)
		{
			return 1;
		}else if(customerId<c.customerId)
		{
			return -1;
		}else {
			return 0;
		}
	}
	/*public int compareTo(CustomerDetails customerDetails)
	{
		return this.customerName.compareTo(customerDetails.customerName);
	}*/
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	@Override
	public String toString() {
		return "CustomerDetails [customerId=" + customerId + ", customerName=" + customerName + ", phoneNumber="
				+ phoneNumber + "]";
	}
	
	
	

}
