package mptMock;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Question6 {
	public static void main(String args[])
	{
		HashMap<Integer,String>map=new HashMap<Integer,String>();
		map.put(3,"sanju");
		map.put(1,"raghu");
		map.put(2,"anu");
		System.out.println(map);
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a key tho check");
		int key=scanner.nextInt();
		if(map.containsKey(key))
		{
			System.out.println(key);
		}
		else
		{
			System.out.println("key not available");
		}
	}

}
