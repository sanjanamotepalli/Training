package mptMock;

public class CustomerNumber {
	public int customerId;
	

	public CustomerNumber(int customerId) {
		super();
		this.customerId = customerId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "CustomerNumber [customerId=" + customerId + "]";
	}

	

}
